<?php
$host = "localhost";
$user = "root";
$pass = ""; 
$db   = "room_scheduling"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$room = $_POST['room'];
$date = $_POST['date'];
$start_time = $_POST['start_time']; 
$end_time = $_POST['end_time'];
$name = $_POST['name'];

$sql = "INSERT INTO bookings (room, date, start_time, end_time, name) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $room, $date, $start_time, $end_time, $name);
$stmt->execute();

$stmt->close();
$conn->close();

echo "Room booked successfully! Redirecting...";
header("refresh:2; url=index.php");
exit();
?>
