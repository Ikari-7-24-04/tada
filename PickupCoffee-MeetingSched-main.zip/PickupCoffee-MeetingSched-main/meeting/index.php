<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="styles.css">
<meta charset="utf-8">
<title> Room Scheduling </title>
</head>
<body>
    <div class="TopTitle">
        <h1 class="meetupCoffee">MEETUP COFFEE</h1>
    </div>
    <div class="line">
      <div class="announcement-text">📢 Please arrive 5 minutes early • 📢 Please arrive 5 minutes early • 
    📢 Please arrive 5 minutes early • 📢 Please arrive 5 minutes early</div>
    </div>
    <main class="layout">
    <!-- Sidebar: the scheduling form -->
    <aside class="scheduler">
      <h2>Book a Room</h2>

      <form action="book.php" method="POST" class="formz">
        <label>Room:</label>
        <select name="room" required>
        <option value="Room A">Room A</option>
        <option value="Room B">Room B</option>
    </select><br>

     <label>Date:</label>
        <input type="date" name="date" required><br>

        <label>Start Time:</label>
            <input type="time" name="start_time" required><br>
        <label>End Time:</label>
            <input type="time" name="end_time" required><br>

     <label>Your Name:</label>
        <input type="text" name="name" required><br>

        <input type="submit" value="Reserve">
        <!-- form fields here -->
      </form>
    </aside>

    <!-- Main content: view of meetings -->
    <section class="bookings">
      <h2>Scheduled Meetings</h2>
      <!-- display booked meetings here -->
      <?php
            // Connect to the database
            $conn = new mysqli("localhost", "root", "", "room_scheduling");

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch all bookings
            $sql = "SELECT room, date, start_time, end_time, name FROM bookings ORDER BY date, start_time";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li><strong>{$row['room']}</strong> - {$row['date']} from {$row['start_time']} to {$row['end_time']} (Booked by: {$row['name']})</li>";

                }
                echo "</ul>";
            } else {
                echo "<p>No bookings yet.</p>";
            }

            $conn->close();
            ?>

    </section>
  </main>



</body>
</html>